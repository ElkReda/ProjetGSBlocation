const mysql = require('mysql');

// Connexion à la BDD
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'gestion_location'
});

connection.connect((err) => {
    if (err) {
        console.error('Erreur de connexion à la base de données :', err);
        return;
    }
    console.log('Connexion à la base de données réussie.');
});

// Filtres appartements
function getFilteredAppartements(minPrice,maxPrice,typAppart,arrondissement,etage,ascenseur,callback) {
    let sql = 'SELECT * FROM appartements WHERE 1';
    
    if (minPrice && maxPrice) {
        sql += ' AND PRIX_LOC BETWEEN ? AND ?';
        sql = sql.replace('?', minPrice);
        sql = sql.replace('?', maxPrice);
    }

    if (typAppart && typAppart !== '--') {
        sql += ' AND TYPAPPART = ?';
        sql = sql.replace('?', typAppart);
    }

    if (arrondissement && arrondissement !== '--') {
        sql += ' AND ARRONDISSEMENT = ?';
        sql = sql.replace('?', arrondissement);
    }

    if (etage && etage !== '--') {
        sql += ' AND ETAGE = ?';
        sql = sql.replace('?', etage);
    }

    if (ascenseur) {
        sql += ' AND ASCENSEUR = 1';
    }
    console.log(sql)
    connection.query(sql,(error, results) => {
        if (error) {
            console.error('Erreur lors de la récupération des données :', error);
            callback(error, null);
        } else {
            callback(null, results);
        }
    });
}
module.exports = getFilteredAppartements;