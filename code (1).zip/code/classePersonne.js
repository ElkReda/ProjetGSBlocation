class Personne {
    constructor(id,nom,prenom,age,codeVille,tel) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.codeVille = codeVille;
        this.tel = tel;
    }

    ajouterPersonne() {
        
    }
}