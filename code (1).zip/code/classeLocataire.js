class Locataire extends Personne {
    constructor(rib,telBanque) {
        this.rib = rib;
        this.telBanque = telBanque;
    }

    occuper(){
        
    }
}