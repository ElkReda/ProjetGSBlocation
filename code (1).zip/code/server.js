const express = require('express');
const getFilteredAppartements = require('./requete');

const app = express();
const PORT = 3000;

app.get('/appartements', (req, res) => {
    getFilteredAppartements((error, results) => {
        if (error) {
            res.status(500).json({ error: 'Erreur lors de la récupération des données' });
        } else {
            res.json(results);
        }
    });
});

app.listen(PORT, () => {
    console.log(`Serveur démarré sur le port ${PORT}`);
});

//ACCES AU SERVEUR http://localhost:3000/appartements